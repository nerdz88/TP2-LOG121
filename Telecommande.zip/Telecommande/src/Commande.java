public interface Commande {

    void execute();

}
