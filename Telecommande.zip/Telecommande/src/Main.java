public class Main {

    public static void main(String[] args) {

        Telecommande t = new Telecommande();
        Ventilateur v = new Ventilateur("VENT1");
        AmpouleGradeable ag = new AmpouleGradeable("AG1");
        AmpouleNormal an = new AmpouleNormal("AN1");

        try {
            t.attachAppareil(v);
            t.attachAppareil(ag);
            t.attachAppareil(an);
        } catch (Exception e) {
            e.printStackTrace();
        }

        t.afficher();

        Commande[][] commandes = t.getCommandes();

        for(int i = 0; i < 3; i++){
            for(int j = 0; j < t.MAXBOUTONS; j++){
                commandes[i][j].execute();
            }
        }

    }

}
